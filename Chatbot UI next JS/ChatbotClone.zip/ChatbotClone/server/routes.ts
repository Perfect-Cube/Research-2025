import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Get all chats
  app.get("/api/chats", async (req, res) => {
    try {
      // For simplicity, we're using user ID 1 (the default user)
      const userId = 1;
      const chats = await storage.getChatsByUserId(userId);
      res.json(chats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chats" });
    }
  });
  
  // Get a specific chat
  app.get("/api/chats/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const chat = await storage.getChat(id);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      res.json(chat);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat" });
    }
  });
  
  // Create a new chat
  app.post("/api/chats", async (req, res) => {
    try {
      const validatedChat = insertChatSchema.parse(req.body);
      const chat = await storage.createChat(validatedChat);
      res.status(201).json(chat);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chat data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create chat" });
    }
  });
  
  // Get messages for a chat
  app.get("/api/chats/:id/messages", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const chat = await storage.getChat(chatId);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      const messages = await storage.getMessagesByChatId(chatId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // Add a message to a chat
  app.post("/api/chats/:id/messages", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const chat = await storage.getChat(chatId);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      const messageData = { ...req.body, chatId };
      const validatedMessage = insertMessageSchema.parse(messageData);
      const message = await storage.createMessage(validatedMessage);
      
      // If this is a user message, simulate an AI response after a short delay
      if (validatedMessage.isUserMessage) {
        setTimeout(async () => {
          const aiResponse = {
            content: generateAIResponse(validatedMessage.content),
            isUserMessage: false,
            chatId
          };
          await storage.createMessage(aiResponse);
        }, 1000);
      }
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  return httpServer;
}

// Simple AI response generator function
function generateAIResponse(userMessage: string): string {
  // Normalize the user message for easier matching
  const normalizedMessage = userMessage.toLowerCase();
  
  // Basic response patterns
  if (normalizedMessage.includes("hello") || normalizedMessage.includes("hi")) {
    return "Hello! How can I assist you today?";
  }
  
  if (normalizedMessage.includes("how are you")) {
    return "I'm just a AI assistant, but thanks for asking! How can I help you?";
  }
  
  if (normalizedMessage.includes("neural network") || normalizedMessage.includes("machine learning") || normalizedMessage.includes("ai")) {
    return "Neural networks are computing systems inspired by the biological neural networks in human brains. They typically have an input layer, one or more hidden layers, and an output layer. The learning process involves adjusting the weights between neurons to minimize the difference between predicted and actual outputs. Neural networks excel at tasks like image recognition and natural language processing.";
  }
  
  if (normalizedMessage.includes("help") || normalizedMessage.includes("explain")) {
    return "I'd be happy to help! Please provide more details about what you'd like me to explain, and I'll do my best to assist you.";
  }
  
  // Default response for other queries
  return "That's an interesting question. As an AI assistant, I'm designed to provide information on a wide range of topics. Could you provide more context or specifics about what you'd like to know?";
}
