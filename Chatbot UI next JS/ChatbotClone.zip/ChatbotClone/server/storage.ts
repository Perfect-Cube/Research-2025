import { 
  users, type User, type InsertUser,
  chats, type Chat, type InsertChat,
  messages, type Message, type InsertMessage 
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Chat methods
  getChat(id: number): Promise<Chat | undefined>;
  getChatsByUserId(userId: number): Promise<Chat[]>;
  createChat(chat: InsertChat): Promise<Chat>;
  
  // Message methods
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByChatId(chatId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chats: Map<number, Chat>;
  private messages: Map<number, Message>;
  private userIdCounter: number;
  private chatIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.chats = new Map();
    this.messages = new Map();
    this.userIdCounter = 1;
    this.chatIdCounter = 1;
    this.messageIdCounter = 1;
    
    // Initialize with a default user and chat
    const defaultUser: User = {
      id: this.userIdCounter++,
      username: "user",
      password: "password"
    };
    this.users.set(defaultUser.id, defaultUser);
    
    const defaultChat: Chat = {
      id: this.chatIdCounter++,
      title: "AI Assistant Chat",
      createdAt: new Date(),
      userId: defaultUser.id
    };
    this.chats.set(defaultChat.id, defaultChat);
    
    const welcomeMessage: Message = {
      id: this.messageIdCounter++,
      content: "Hello! How can I assist you today?",
      isUserMessage: false,
      createdAt: new Date(),
      chatId: defaultChat.id
    };
    this.messages.set(welcomeMessage.id, welcomeMessage);
    
    // Add two more sample chats
    const chat2: Chat = {
      id: this.chatIdCounter++,
      title: "Article Summarization",
      createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
      userId: defaultUser.id
    };
    this.chats.set(chat2.id, chat2);
    
    const chat3: Chat = {
      id: this.chatIdCounter++,
      title: "Code Review Session",
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      userId: defaultUser.id
    };
    this.chats.set(chat3.id, chat3);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Chat methods
  async getChat(id: number): Promise<Chat | undefined> {
    return this.chats.get(id);
  }

  async getChatsByUserId(userId: number): Promise<Chat[]> {
    return Array.from(this.chats.values())
      .filter((chat) => chat.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createChat(insertChat: InsertChat): Promise<Chat> {
    const id = this.chatIdCounter++;
    const chat: Chat = { 
      ...insertChat, 
      id,
      createdAt: new Date()
    };
    this.chats.set(id, chat);
    return chat;
  }

  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessagesByChatId(chatId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.chatId === chatId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const message: Message = { 
      ...insertMessage, 
      id,
      createdAt: new Date()
    };
    this.messages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
