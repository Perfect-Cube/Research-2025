import { useEffect, useRef, useState } from "react";
import { useParams } from "wouter";
import { ChatHeader } from "@/components/chat/chat-header";
import { ChatInput } from "@/components/chat/chat-input";
import { ChatMessage } from "@/components/chat/chat-message";
import { ChatSidebar } from "@/components/chat/chat-sidebar";
import { ChatWelcome } from "@/components/chat/chat-welcome";
import { TypingIndicator } from "@/components/chat/typing-indicator";
import { useChat } from "@/hooks/use-chat";

export default function ChatPage() {
  const { id } = useParams();
  const { messages, loading, selectedChat, setSelectedChatId } = useChat();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Set the selected chat based on the URL parameter
  useEffect(() => {
    if (id) {
      setSelectedChatId(parseInt(id));
    }
  }, [id, setSelectedChatId]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      <ChatSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <ChatHeader 
          title="ChatbotUI" 
          onMobileMenuToggle={() => setSidebarOpen(true)}
        />
        
        <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide">
          {messages.length === 0 ? (
            <ChatWelcome />
          ) : (
            <>
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  content={message.content}
                  isUserMessage={message.isUserMessage}
                  timestamp={new Date(message.createdAt)}
                />
              ))}
              
              {loading && <TypingIndicator />}
              
              {/* Empty div for scrolling to bottom */}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>
        
        <ChatInput />
      </main>
    </div>
  );
}
