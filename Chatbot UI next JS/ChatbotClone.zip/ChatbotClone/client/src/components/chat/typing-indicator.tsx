import { Bot } from "lucide-react";
import { motion } from "framer-motion";

export function TypingIndicator() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col gap-2 items-start"
    >
      <div className="flex items-center gap-2 max-w-3xl">
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <Bot className="h-5 w-5" />
        </div>
        <div className="bg-muted p-3 rounded-lg rounded-tl-none">
          <div className="flex space-x-1">
            <motion.span 
              className="w-2 h-2 bg-muted-foreground/50 rounded-full"
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.4, repeat: Infinity }}
            />
            <motion.span 
              className="w-2 h-2 bg-muted-foreground/50 rounded-full"
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.4, delay: 0.2, repeat: Infinity }}
            />
            <motion.span 
              className="w-2 h-2 bg-muted-foreground/50 rounded-full"
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.4, delay: 0.4, repeat: Infinity }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
