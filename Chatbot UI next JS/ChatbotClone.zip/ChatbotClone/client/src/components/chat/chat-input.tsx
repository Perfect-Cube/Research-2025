import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useChat } from "@/hooks/use-chat";
import { SendIcon } from "lucide-react";

export function ChatInput() {
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { sendMessage, loading } = useChat();

  // Auto-resize textarea as user types
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      const newHeight = Math.min(textarea.scrollHeight, 120);
      textarea.style.height = `${newHeight}px`;
    }
  }, [message]);

  const handleSend = () => {
    if (message.trim() && !loading) {
      sendMessage(message);
      setMessage("");
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t border-border p-4">
      <div className="max-w-4xl mx-auto">
        <div className="relative">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message here..."
            className="w-full pr-12 resize-none min-h-[44px] max-h-[120px]"
            disabled={loading}
          />
          <Button
            size="icon"
            className="absolute right-3 bottom-3 h-8 w-8 text-primary hover:text-primary-foreground"
            variant="ghost"
            onClick={handleSend}
            disabled={!message.trim() || loading}
          >
            <SendIcon className="h-5 w-5" />
          </Button>
        </div>
        <div className="text-xs text-muted-foreground mt-2 px-2">
          AI responses are generated based on your inputs. Press Enter to send.
        </div>
      </div>
    </div>
  );
}
