import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  PlusIcon, 
  Search, 
  User, 
  Moon, 
  Sun, 
  Settings, 
  MessageSquare,
  X
} from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { formatDistanceToNow } from "date-fns";
import { type Chat } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useTheme } from "@/hooks/use-theme";

interface ChatSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ChatSidebar({ isOpen, onClose }: ChatSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { chats, createNewChat, setSelectedChatId } = useChat();
  const [location, navigate] = useLocation();
  const { theme, toggleTheme } = useTheme();
  
  // Filter chats based on search query
  const filteredChats = chats.filter(chat => 
    chat.title.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleChatSelect = (chat: Chat) => {
    setSelectedChatId(chat.id);
    navigate(`/chat/${chat.id}`);
    onClose(); // Close sidebar on mobile
  };
  
  const handleNewChat = () => {
    createNewChat();
    onClose(); // Close sidebar on mobile
  };
  
  return (
    <aside 
      className={cn(
        "flex flex-col w-64 h-full border-r border-border bg-background p-4 transition-all duration-300 ease-in-out",
        isOpen 
          ? "fixed inset-0 z-50 md:relative md:inset-auto" 
          : "hidden md:flex"
      )}
    >
      {isOpen && (
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute top-4 right-4 md:hidden" 
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </Button>
      )}
      
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-semibold">ChatbotUI</h1>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleNewChat}
        >
          <PlusIcon className="h-5 w-5" />
        </Button>
      </div>
      
      <div className="flex items-center gap-2 p-2 bg-muted rounded-md mb-4">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search chats..."
          className="bg-transparent border-none focus-visible:ring-0 w-full h-7 text-sm"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        <div className="space-y-1">
          {filteredChats.length > 0 ? (
            filteredChats.map(chat => (
              <div
                key={chat.id}
                className={cn(
                  "p-2 rounded-md flex items-center gap-2 hover:bg-muted cursor-pointer transition-colors",
                  location === `/chat/${chat.id}` ? "bg-muted" : ""
                )}
                onClick={() => handleChatSelect(chat)}
              >
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1 truncate text-sm">{chat.title}</div>
                <div className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(chat.createdAt), { addSuffix: false })}
                </div>
              </div>
            ))
          ) : (
            <div className="p-2 text-sm text-muted-foreground">
              No chats found
            </div>
          )}
        </div>
      </div>
      
      <div className="border-t border-border pt-4 mt-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
              <User className="h-5 w-5" />
            </div>
            <div className="text-sm font-medium">User</div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleTheme}
          >
            {theme === 'dark' ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>
        </div>
        
        <Button 
          variant="ghost" 
          className="w-full justify-start text-sm text-muted-foreground"
        >
          <Settings className="h-4 w-4 mr-2" />
          <span>Settings</span>
        </Button>
      </div>
    </aside>
  );
}
