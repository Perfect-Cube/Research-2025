import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { User, Bot } from "lucide-react";
import { motion } from "framer-motion";

interface ChatMessageProps {
  content: string;
  isUserMessage: boolean;
  timestamp: Date;
}

export function ChatMessage({ content, isUserMessage, timestamp }: ChatMessageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "flex flex-col gap-2",
        isUserMessage ? "items-end" : "items-start"
      )}
    >
      <div className="flex items-center gap-2 max-w-3xl">
        {!isUserMessage && (
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <Bot className="h-5 w-5" />
          </div>
        )}
        
        <div 
          className={cn(
            "p-3 rounded-lg",
            isUserMessage 
              ? "bg-primary text-primary-foreground rounded-tr-none" 
              : "bg-muted rounded-tl-none"
          )}
        >
          <div className="whitespace-pre-wrap">{content}</div>
        </div>
        
        {isUserMessage && (
          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground">
            <User className="h-5 w-5" />
          </div>
        )}
      </div>
      
      <div 
        className={cn(
          "text-xs text-muted-foreground",
          isUserMessage ? "pr-10" : "pl-10"
        )}
      >
        {format(timestamp, "h:mm a")}
      </div>
    </motion.div>
  );
}
