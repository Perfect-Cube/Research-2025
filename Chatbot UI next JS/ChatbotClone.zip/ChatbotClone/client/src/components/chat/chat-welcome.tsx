import { Card, CardContent } from "@/components/ui/card";

export function ChatWelcome() {
  return (
    <div className="flex justify-center mb-8 mt-4">
      <Card className="bg-muted/50 border-none max-w-md">
        <CardContent className="p-4">
          <h3 className="text-lg font-medium mb-2">Welcome to ChatbotUI</h3>
          <p className="text-sm text-muted-foreground">
            This is a minimalist chat interface. Start typing below to interact with the AI assistant.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
