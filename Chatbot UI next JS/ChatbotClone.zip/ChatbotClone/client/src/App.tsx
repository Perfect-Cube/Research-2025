import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import ChatPage from "@/pages/chat-page";
import { useTheme } from "@/hooks/use-theme";
import { ChatProvider } from "./context/chat-context";

function Router() {
  return (
    <Switch>
      <Route path="/" component={ChatPage} />
      <Route path="/chat/:id" component={ChatPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Set up theme
  useTheme();
  
  return (
    <ChatProvider>
      <Router />
      <Toaster />
    </ChatProvider>
  );
}

export default App;
