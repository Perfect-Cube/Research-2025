import { createContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { type Chat, type Message } from "@shared/schema";

interface ChatContextType {
  chats: Chat[];
  messages: Message[];
  selectedChat: Chat | null;
  selectedChatId: number | null;
  loading: boolean;
  setSelectedChatId: (id: number | null) => void;
  sendMessage: (content: string) => void;
  createNewChat: () => void;
}

export const ChatContext = createContext<ChatContextType | null>(null);

interface ChatProviderProps {
  children: ReactNode;
}

export function ChatProvider({ children }: ChatProviderProps) {
  const [selectedChatId, setSelectedChatId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch all chats
  const { 
    data: chats = [], 
    isLoading: isLoadingChats,
    error: chatsError
  } = useQuery({
    queryKey: ["/api/chats"],
    staleTime: 10000 // 10 seconds
  });
  
  // Set first chat as selected if none is selected
  useEffect(() => {
    if (!selectedChatId && chats.length > 0 && !isLoadingChats) {
      setSelectedChatId(chats[0].id);
    }
  }, [chats, selectedChatId, isLoadingChats]);
  
  // Show error toast if chats fetch fails
  useEffect(() => {
    if (chatsError) {
      toast({
        title: "Error loading chats",
        description: "Please try again later.",
        variant: "destructive"
      });
    }
  }, [chatsError, toast]);
  
  // Fetch messages for selected chat
  const { 
    data: messages = [], 
    isLoading: isLoadingMessages,
    error: messagesError 
  } = useQuery({
    queryKey: ["/api/chats", selectedChatId, "messages"],
    enabled: !!selectedChatId,
    staleTime: 5000 // 5 seconds
  });
  
  // Selected chat
  const selectedChat = chats.find(chat => chat.id === selectedChatId) || null;
  
  // Send message mutation
  const { mutate: sendMessageMutation, isPending: isSending } = useMutation({
    mutationFn: async ({ content, chatId }: { content: string, chatId: number }) => {
      const res = await apiRequest("POST", `/api/chats/${chatId}/messages`, {
        content,
        isUserMessage: true
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats", selectedChatId, "messages"] });
    },
    onError: () => {
      toast({
        title: "Failed to send message",
        description: "Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Create new chat mutation
  const { mutate: createChatMutation } = useMutation({
    mutationFn: async (title: string) => {
      const res = await apiRequest("POST", "/api/chats", {
        title,
        userId: 1 // Default user
      });
      return res.json();
    },
    onSuccess: (newChat) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      setSelectedChatId(newChat.id);
    },
    onError: () => {
      toast({
        title: "Failed to create new chat",
        description: "Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Send message function
  const sendMessage = (content: string) => {
    if (!selectedChatId) {
      // Create a new chat if none is selected
      createChatMutation("New Chat");
      return;
    }
    
    sendMessageMutation({ content, chatId: selectedChatId });
  };
  
  // Create new chat function
  const createNewChat = () => {
    createChatMutation("New Chat");
  };
  
  // Loading state
  const loading = isLoadingMessages || isSending;
  
  return (
    <ChatContext.Provider
      value={{
        chats,
        messages,
        selectedChat,
        selectedChatId,
        loading,
        setSelectedChatId,
        sendMessage,
        createNewChat
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}
