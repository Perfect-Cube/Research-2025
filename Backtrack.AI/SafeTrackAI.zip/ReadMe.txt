Use Ollama run gemma3:1b
then execute prefilter.py and post filter.py
attach the main llm in between